package com.company.phonedirectory

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/** Keeps the SIP core alive while the app task is not visible. */
class SIPForegroundService : Service() {
    companion object {
        const val ACTION_CONNECT = "com.company.phonedirectory.SIP_CONNECT"
        private const val CHANNEL_ID = "atfil_sip_calls"
        private const val NOTIFICATION_ID = 861
        @Volatile private var serviceInstance: SIPForegroundService? = null
        fun notifyIncomingCall(remote: String) {
            serviceInstance?.showIncomingCall(remote)
        }
    }

    override fun onCreate() {
        super.onCreate()
        serviceInstance = this
        createChannel()
    }

    private fun showIncomingCall(remote: String) {
        getSystemService(NotificationManager::class.java).notify(
            NOTIFICATION_ID + 1,
            notification("Incoming call from $remote").apply {
                // Notification opens the in-app call screen when tapped.
            }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification("SIP service starting"), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification("SIP service starting"))
        }
        val prefs = getSharedPreferences("sip_account", MODE_PRIVATE)
        val username = intent?.getStringExtra("username") ?: prefs.getString("username", "").orEmpty()
        val domain = intent?.getStringExtra("domain") ?: prefs.getString("domain", "").orEmpty()
        val password = intent?.getStringExtra("password") ?: prefs.getString("password", "").orEmpty()
        val port = intent?.getIntExtra("port", prefs.getString("port", "5060")?.toIntOrNull() ?: 5060) ?: 5060
        val transport = intent?.getStringExtra("transport") ?: prefs.getString("transport", "UDP") ?: "UDP"
        if (username.isNotBlank() && domain.isNotBlank() && password.isNotBlank()) {
            try {
                if (SIPEngine.core == null) {
                    SIPEngine.connect(applicationContext, username, domain, password, port, transport)
                }
                getSystemService(NotificationManager::class.java)
                    .notify(NOTIFICATION_ID, notification("SIP line active · $username"))
            } catch (e: Exception) {
                getSystemService(NotificationManager::class.java)
                    .notify(NOTIFICATION_ID, notification("SIP connection failed"))
            }
        }
        return START_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "SIP calls", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Keeps the AT-FIL SIP line available for calls"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, SIPActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle("AT-FIL Téléphone")
            .setContentText(message)
            .setContentIntent(openApp)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        serviceInstance = null
        super.onDestroy()
    }
}
