
package com.company.phonedirectory

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.content.Context
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.linphone.core.Account
import org.linphone.core.Call
import org.linphone.core.Core
import org.linphone.core.CoreListenerStub
import org.linphone.core.Factory
import org.linphone.core.TransportType

/**
 * SIP calling screen for HiPath Directory.
 * Audio calling with Liblinphone.
 */
class SIPActivity : Activity() {

    private lateinit var username: EditText
    private lateinit var domain: EditText
    private lateinit var password: EditText
    private lateinit var port: EditText
    private lateinit var number: EditText

    // Keep the actual status internally; display only the colored dot.
    private lateinit var status: TextView
    private lateinit var configPanel: LinearLayout
    private lateinit var phonePanel: LinearLayout
    private lateinit var configTab: Button
    private lateinit var phoneTab: Button
    private lateinit var statusDot: TextView

    private lateinit var callState: TextView
    private lateinit var transport: Spinner
    private lateinit var connectButton: Button
    private lateinit var callButton: Button
    private lateinit var acceptButton: Button
    private lateinit var rejectButton: Button
    private lateinit var muteButton: Button
    private lateinit var speakerButton: Button

    private var muted = false
    private var speaker = false

    private val prefs by lazy {
        getSharedPreferences("sip_account", MODE_PRIVATE)
    }

    private val cyan = Color.rgb(34, 197, 94)
    private val green = Color.rgb(22, 163, 74)
    private val red = Color.rgb(239, 83, 80)
    private val statusOrange = Color.rgb(255, 152, 0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        buildUi()
        loadSavedAccount()
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 502)
        }

        number.setText(intent.getStringExtra("dial_number").orEmpty())
        showPage(intent.getBooleanExtra("show_settings", false))
        if (intent.getStringExtra("dial_number").orEmpty().isNotBlank()) showPage(false)

        SIPEngine.listener = { message, incoming ->
            runOnUiThread {
                status.text = message
                updateStatusIndicator(message)

                callState.text =
                    if (incoming) "Incoming call — answer or reject"
                    else message

                acceptButton.visibility =
                    if (incoming) View.VISIBLE else View.GONE

                rejectButton.visibility =
                    if (incoming || SIPEngine.activeCall != null) {
                        View.VISIBLE
                    } else {
                        View.GONE
                    }
            }
        }

        SIPEngine.statusListener = { message ->
            runOnUiThread {
                status.text = message
                updateStatusIndicator(message)
            }
        }

        refreshState()

        connectButton.setOnClickListener {
            connectAccount()
        }

        callButton.setOnClickListener {
            makeCall()
        }

        acceptButton.setOnClickListener {
            SIPEngine.activeCall?.let {
                try {
                    it.accept()
                    callState.text = "Connecting..."
                } catch (e: Exception) {
                    showMessage("Could not answer: ${e.message}")
                }
            }
        }

        rejectButton.setOnClickListener {
            try {
                SIPEngine.activeCall?.terminate()
            } catch (_: Exception) {
            }

            callState.text = "Call ended"
            acceptButton.visibility = View.GONE
            rejectButton.visibility = View.GONE
        }

        muteButton.setOnClickListener {
            muted = !muted
            SIPEngine.activeCall?.microphoneMuted = muted

            muteButton.text =
                if (muted) "Unmute microphone"
                else "Mute microphone"
        }

        speakerButton.setOnClickListener {
            speaker = !speaker
            SIPEngine.setSpeaker(speaker)

            speakerButton.text =
                if (speaker) "Speaker: ON"
                else "Speaker: OFF"
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(20))
            setBackgroundColor(Ui.background(this@SIPActivity))
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            addView(root)
        }

        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "SIP CALLING"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(cyan)
        })

        root.addView(TextView(this).apply {
            text = "VoIP account"
            textSize = 27f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Ui.text(this@SIPActivity))
            setPadding(0, dp(5), 0, dp(4))
        })

        root.addView(TextView(this).apply {
            text = "Configure your line separately from the phone keypad."
            textSize = 14f
            setTextColor(Ui.muted(this@SIPActivity))
            setPadding(0, 0, 0, dp(14))
        })

        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        configTab = button("⚙ Server settings", green, Color.WHITE)
        phoneTab = button("☎ Phone", Color.rgb(35, 50, 65), Color.WHITE)
        nav.addView(configTab, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
        nav.addView(phoneTab, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(5) })
        root.addView(nav, matchParams(4))

        configPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        phonePanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        root.addView(configPanel, LinearParamsCompat())
        root.addView(phonePanel, LinearParamsCompat())
        configTab.setOnClickListener { showPage(true) }
        phoneTab.setOnClickListener { showPage(false) }

        configPanel.addView(TextView(this).apply {
            text = "SERVER CONFIGURATION"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(green)
            setPadding(0, dp(14), 0, dp(8))
        })
        username = field(configPanel, "Username / Extension", "e.g. 861")
        domain = field(configPanel, "SIP server / Domain", "e.g. 192.168.1.247")
        password = field(configPanel, "SIP password", "Account password", true)
        port = field(configPanel, "SIP port", "5060")

        transport = Spinner(this)
        transport.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("UDP", "TCP", "TLS")
        )

        configPanel.addView(label("Transport"))

        configPanel.addView(
            transport,
            LinearLayout.LayoutParams(-1, dp(48)).apply {
                bottomMargin = dp(10)
            }
        )

        connectButton = button(
            "Save server & Connect",
            green,
            Color.WHITE
        )

        configPanel.addView(connectButton, matchParams(10))

        // Connection indicator: colored dot only.
        val statusPanel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))

            background = rounded(
                if (Ui.isDark(this@SIPActivity)) {
                    Color.rgb(13, 43, 48)
                } else {
                    Color.rgb(232, 249, 247)
                },
                12
            )
        }

        statusDot = TextView(this).apply {
            text = "●"
            textSize = 22f
            gravity = Gravity.CENTER
            includeFontPadding = false
            setTextColor(red)
            contentDescription = "SIP connection status"
        }

        statusPanel.addView(
            statusDot,
            LinearLayout.LayoutParams(dp(32), dp(32))
        )

        status = TextView(this).apply {
            text = SIPEngine.status
            textSize = 13f
            setTextColor(Ui.text(this@SIPActivity))
            maxLines = 3
        }

        statusPanel.addView(
            status,
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) }
        )

        configPanel.addView(statusPanel, matchParams(10))

        phonePanel.addView(TextView(this).apply {
            text = "PHONE"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Ui.text(this@SIPActivity))
            setPadding(0, dp(6), 0, dp(8))
        })

        number = field(phonePanel, "Number to call", "e.g. 100 or 200")

        callButton = button(
            "☎  Call",
            green,
            Color.rgb(5, 30, 23)
        )

        phonePanel.addView(callButton, matchParams(8))

        callState = label("Ready")
        callState.setPadding(0, dp(10), 0, dp(8))
        phonePanel.addView(callState)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        muteButton = button(
            "Mute microphone",
            Color.rgb(40, 52, 73),
            Color.WHITE
        )

        speakerButton = button(
            "Speaker: OFF",
            Color.rgb(40, 52, 73),
            Color.WHITE
        )

        controls.addView(
            muteButton,
            LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                marginEnd = dp(6)
            }
        )

        controls.addView(
            speakerButton,
            LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                marginStart = dp(6)
            }
        )

        phonePanel.addView(controls, matchParams(8))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        acceptButton = button(
            "Answer",
            green,
            Color.rgb(5, 30, 23)
        )

        rejectButton = button(
            "Hang up / Reject",
            red,
            Color.WHITE
        )

        acceptButton.visibility = View.GONE
        rejectButton.visibility = View.GONE

        actions.addView(
            acceptButton,
            LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                marginEnd = dp(6)
            }
        )

        actions.addView(
            rejectButton,
            LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                marginStart = dp(6)
            }
        )

        phonePanel.addView(actions, matchParams(8))

        phonePanel.addView(TextView(this).apply {
            text = "Incoming calls while the app is closed require a persistent call service and, for reliable wake-up, compatible SIP push support from your provider."
            textSize = 12f
            setTextColor(Ui.muted(this@SIPActivity))
            setPadding(0, dp(16), 0, dp(8))
        })

        updateStatusIndicator(SIPEngine.status)
    }

    private fun showPage(serverSettings: Boolean) {
        configPanel.visibility = if (serverSettings) View.VISIBLE else View.GONE
        phonePanel.visibility = if (serverSettings) View.GONE else View.VISIBLE
        configTab.background = rounded(if (serverSettings) green else Color.rgb(35, 50, 65), 13)
        phoneTab.background = rounded(if (serverSettings) Color.rgb(35, 50, 65) else green, 13)
    }

    /** Changes the indicator color based on SIP status. */
    private fun updateStatusIndicator(message: String) {
        if (!::statusDot.isInitialized) return

        val m = message.lowercase()

        val color = when {
            m.contains("registration failed") ||
            m.contains("connection failed") ||
            m.contains("not connected") ||
            m.contains("disconnected") ||
            m.contains("call error") ||
            m.contains("error") ||
            m.contains("failed") ||
            m.contains("call ended") ||
            m.contains("call finished") -> red

            m.contains("registered") ||
            m == "connected" ||
            m.contains("call in progress") -> green

            m.contains("connecting") ||
            m.contains("registering") ||
            m.contains("progress") ||
            m.contains("ringing") ||
            m.contains("starting call") ||
            m.contains("incoming call") -> statusOrange

            else -> red
        }

        statusDot.setTextColor(color)
    }

    private fun field(
        parent: LinearLayout,
        title: String,
        hintText: String,
        isPassword: Boolean = false
    ): EditText {
        parent.addView(label(title))

        val edit = EditText(this).apply {
            hint = hintText
            textSize = 15f
            setSingleLine(true)
            setTextColor(Ui.text(this@SIPActivity))
            setHintTextColor(Ui.muted(this@SIPActivity))

            background = rounded(
                if (Ui.isDark(this@SIPActivity)) {
                    Color.rgb(30, 41, 59)
                } else {
                    Color.WHITE
                },
                12
            )

            setPadding(dp(13), 0, dp(13), 0)

            inputType = if (isPassword) {
                129
            } else {
                android.text.InputType.TYPE_CLASS_TEXT
            }
        }

        parent.addView(
            edit,
            LinearLayout.LayoutParams(-1, dp(49)).apply {
                bottomMargin = dp(9)
            }
        )

        return edit
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Ui.text(this@SIPActivity))
    }

    private fun button(
        textValue: String,
        color: Int,
        textColor: Int
    ) = Button(this).apply {
        text = textValue
        isAllCaps = false
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(textColor)
        background = rounded(color, 13)
    }

    private fun rounded(
        color: Int,
        radius: Int
    ) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun LinearParamsCompat() = LinearLayout.LayoutParams(-1, -2)

    private fun matchParams(top: Int) =
        LinearLayout.LayoutParams(-1, dp(50)).apply {
            topMargin = dp(top)
        }

    private fun loadSavedAccount() {
        username.setText(prefs.getString("username", ""))
        domain.setText(prefs.getString("domain", ""))
        password.setText(prefs.getString("password", ""))
        port.setText(prefs.getString("port", "5060"))

        val savedTransport = prefs.getString("transport", "UDP")
        val index = listOf("UDP", "TCP", "TLS").indexOf(savedTransport)

        transport.setSelection(if (index >= 0) index else 0)
    }

    private fun hasSavedAccount() =
        prefs.getString("username", "").orEmpty().isNotBlank() &&
        prefs.getString("domain", "").orEmpty().isNotBlank()

    private fun connectAccount() {
        val u = username.text.toString().trim()
        val d = domain.text.toString().trim()
        val pw = password.text.toString()
        val p = port.text.toString().trim().ifBlank { "5060" }
        val t = transport.selectedItem.toString()

        if (u.isBlank() || d.isBlank() || pw.isBlank()) {
            showMessage("Enter username, server and password first.")
            return
        }

        val portNumber = p.toIntOrNull()

        if (portNumber == null || portNumber !in 1..65535) {
            showMessage("Enter a valid SIP port.")
            return
        }

        prefs.edit()
            .putString("username", u)
            .putString("domain", d)
            .putString("password", pw)
            .putString("port", p)
            .putString("transport", t)
            .apply()

        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                501
            )
            showMessage("Allow microphone permission, then tap Connect again.")
            return
        }

        try {
            status.text = "Connecting to $d:$p ($t)…"
            updateStatusIndicator(status.text.toString())

            val serviceIntent = android.content.Intent(this, SIPForegroundService::class.java).apply {
                action = SIPForegroundService.ACTION_CONNECT
                putExtra("username", u)
                putExtra("domain", d)
                putExtra("password", pw)
                putExtra("port", portNumber)
                putExtra("transport", t)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            callState.text = "Waiting for SIP registration"
        } catch (e: Exception) {
            status.text = "Connection failed"
            updateStatusIndicator(status.text.toString())
            showMessage(e.message ?: "Could not start SIP")
        }
    }

    private fun makeCall() {
        val target = number.text.toString().trim()

        if (target.isBlank()) {
            showMessage("Enter an extension or SIP number.")
            return
        }

        if (SIPEngine.core == null) {
            showMessage("Save account & Connect first.")
            return
        }

        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                501
            )
            return
        }

        try {
            SIPEngine.call(target)
            callState.text = "Calling $target…"
            rejectButton.visibility = View.VISIBLE
        } catch (e: Exception) {
            showMessage("Call failed: ${e.message ?: "unknown error"}")
        }
    }

    private fun refreshState() {
        status.text = SIPEngine.status
        updateStatusIndicator(SIPEngine.status)

        val call = SIPEngine.activeCall

        if (call != null) {
            callState.text = "Call state: ${call.state}"
            rejectButton.visibility = View.VISIBLE

            acceptButton.visibility =
                if (call.state == Call.State.IncomingReceived) {
                    View.VISIBLE
                } else {
                    View.GONE
                }
        }
    }

    private fun showMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        if (SIPEngine.listener != null) {
            SIPEngine.listener = null
        }

        if (SIPEngine.statusListener != null) {
            SIPEngine.statusListener = null
        }

        super.onDestroy()
    }
}

internal object SIPEngine {

    var core: Core? = null
    var activeCall: Call? = null

    var status: String = "Not connected"

    var listener: ((String, Boolean) -> Unit)? = null
    var statusListener: ((String) -> Unit)? = null

    private var speakerOn = false

    @Synchronized
    fun connect(
        context: Context,
        username: String,
        domain: String,
        password: String,
        port: Int,
        transport: String
    ) {
        try {
            core?.stop()
        } catch (_: Exception) {
        }

        core = null
        activeCall = null

        val factory = Factory.instance()
        val newCore = factory.createCore(null, null, context.applicationContext)

        newCore.isVideoCaptureEnabled = false
        newCore.isVideoDisplayEnabled = false

        newCore.addListener(object : CoreListenerStub() {

            override fun onRegistrationStateChanged(
                core: Core,
                proxyConfig: org.linphone.core.ProxyConfig,
                state: org.linphone.core.RegistrationState,
                message: String
            ) {
                status = when (state) {
                    org.linphone.core.RegistrationState.Ok ->
                        "Registered • $username@$domain"

                    org.linphone.core.RegistrationState.Progress ->
                        "Registering…"

                    org.linphone.core.RegistrationState.Failed ->
                        "Registration failed: $message"

                    org.linphone.core.RegistrationState.Cleared ->
                        "Disconnected"

                    else -> "SIP: $state"
                }

                statusListener?.invoke(status)
                listener?.invoke(status, false)
            }

            override fun onCallStateChanged(
                core: Core,
                call: Call,
                state: Call.State?,
                message: String
            ) {
                activeCall =
                    if (
                        state == Call.State.End ||
                        state == Call.State.Released ||
                        state == Call.State.Error
                    ) {
                        null
                    } else {
                        call
                    }

                val incoming = state == Call.State.IncomingReceived
                if (incoming) {
                    SIPForegroundService.notifyIncomingCall(call.remoteAddress?.username ?: "unknown")
                }

                val label = when (state) {
                    Call.State.IncomingReceived ->
                        "Incoming call from ${call.remoteAddress?.username ?: "unknown"}"

                    Call.State.OutgoingInit ->
                        "Starting call…"

                    Call.State.OutgoingProgress ->
                        "Calling…"

                    Call.State.OutgoingRinging ->
                        "Ringing…"

                    Call.State.Connected ->
                        "Connected"

                    Call.State.StreamsRunning ->
                        "Call in progress"

                    Call.State.End ->
                        "Call ended"

                    Call.State.Error ->
                        "Call error: $message"

                    Call.State.Released ->
                        "Call finished"

                    else -> "Call: $state"
                }

                listener?.invoke(label, incoming)
                statusListener?.invoke(label)
            }
        })

        val identity = factory.createAddress("sip:$username@$domain")
            ?: throw IllegalArgumentException("Invalid SIP identity or domain")

        val server = factory.createAddress(
            "sip:$domain:$port;transport=${transport.lowercase()}"
        ) ?: throw IllegalArgumentException("Invalid SIP server address")

        val auth = factory.createAuthInfo(
            username,
            null,
            password,
            null,
            null,
            domain
        )

        newCore.addAuthInfo(auth)

        val params = newCore.createAccountParams()
        params.identityAddress = identity
        params.serverAddress = server
        params.isRegisterEnabled = true

        val account: Account = newCore.createAccount(params)

        newCore.addAccount(account)
        newCore.defaultAccount = account

        newCore.start()
        core = newCore

        status = "SIP engine started — registering…"

        statusListener?.invoke(status)
        listener?.invoke(status, false)
    }

    fun call(target: String) {
        val c = core
            ?: throw IllegalStateException("SIP account is not connected")

        val clean = target.trim()

        val uri = if (clean.startsWith("sip:", true)) {
            clean
        } else {
            val d = c.defaultAccount?.params?.identityAddress?.domain ?: ""

            if (d.isBlank()) {
                throw IllegalStateException("SIP domain is missing")
            }

            "sip:$clean@$d"
        }

        val created = c.invite(uri)
            ?: throw IllegalStateException(
                "The SIP engine rejected the call request"
            )

        activeCall = created
    }

    fun setSpeaker(enabled: Boolean) {
        speakerOn = enabled

        val c = core ?: return

        val device = c.audioDevices.firstOrNull {
            if (enabled) {
                it.type == org.linphone.core.AudioDevice.Type.Speaker
            } else {
                it.type == org.linphone.core.AudioDevice.Type.Earpiece
            }
        }

        if (device != null) {
            activeCall?.outputAudioDevice = device
            c.defaultOutputAudioDevice = device
        }
    }
}
