package ma.atfil.telephone

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

private const val BG = 0xFF07111F.toInt()
private const val PANEL = 0xFF102A24.toInt()
private const val GREEN = 0xFF19F59A.toInt()
private const val WHITE = 0xFFF4F8FF.toInt()
private const val MUTED = 0xFF9DB3B0.toInt()

class ContactsDb(c: android.content.Context) : SQLiteOpenHelper(c, "atfil_contacts.db", null, 1) {
 override fun onCreate(db: SQLiteDatabase) { db.execSQL("CREATE TABLE contacts(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, number TEXT NOT NULL, service TEXT NOT NULL DEFAULT '')") }
 override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
 fun all(q: String = ""): List<ContactItem> { val out=mutableListOf<ContactItem>(); readableDatabase.rawQuery("SELECT id,name,number,service FROM contacts WHERE name LIKE ? OR number LIKE ? OR service LIKE ? ORDER BY name", arrayOf("%$q%","%$q%","%$q%")).use { while(it.moveToNext()) out.add(ContactItem(it.getLong(0),it.getString(1),it.getString(2),it.getString(3))) }; return out }
 fun save(item: ContactItem) { val v=ContentValues().apply { put("name",item.name);put("number",item.number);put("service",item.service) }; if(item.id==0L) writableDatabase.insert("contacts",null,v) else writableDatabase.update("contacts",v,"id=?", arrayOf(item.id.toString())) }
 fun delete(id: Long) { writableDatabase.delete("contacts","id=?",arrayOf(id.toString())) }
}
data class ContactItem(val id:Long=0,val name:String,val number:String,val service:String="")

class MainActivity : Activity() {
 private lateinit var db: ContactsDb; private lateinit var list: LinearLayout; private lateinit var count: TextView; private lateinit var search: EditText
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); db=ContactsDb(this); render() }
 override fun onResume() { super.onResume(); if(::list.isInitialized) refresh() }
 private fun render() {
  val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(22),dp(20),dp(16));setBackgroundColor(BG) }
  val top=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL; orientation=LinearLayout.HORIZONTAL }
  top.addView(TextView(this).apply { text="AT-FIL\nTÉLÉPHONE PROFESSIONNEL";setTextColor(WHITE);textSize=23f;typeface=Typeface.DEFAULT_BOLD; setLineSpacing(dp(2).toFloat(),1f) }, LinearLayout.LayoutParams(0,-2,1f))
  top.addView(action("☏  SIP",GREEN, BG) { startActivity(Intent(this,SipActivity::class.java)) })
  root.addView(top); root.addView(space(18))
  val hero=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(18));background=rounded(PANEL,dp(22)) }
  hero.addView(label("VOTRE ANNUAIRE",GREEN,14f));count=label("0 contact",WHITE,32f).also { it.setPadding(0,dp(8),0,dp(4));it.typeface=Typeface.DEFAULT_BOLD };hero.addView(count);hero.addView(label("Répertoire professionnel AT-FIL",MUTED,14f));root.addView(hero)
  root.addView(space(22));root.addView(label("Rechercher un contact",WHITE,20f).apply{typeface=Typeface.DEFAULT_BOLD});root.addView(space(8))
  search=EditText(this).apply { hint="Nom, numéro ou service…";setHintTextColor(MUTED);setTextColor(WHITE);textSize=16f;singleLine=true;setPadding(dp(16),dp(12),dp(16),dp(12));background=rounded(PANEL,dp(14)) };root.addView(search)
  root.addView(space(18));val title=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL};title.addView(label("Tous les contacts",WHITE,21f).apply{typeface=Typeface.DEFAULT_BOLD},LinearLayout.LayoutParams(0,-2,1f));title.addView(action("+ Ajouter",GREEN,BG){edit(null)});root.addView(title)
  root.addView(space(10));val sc=ScrollView(this);list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
  root.addView(space(10));root.addView(label("Designed by Kerouach Mohamed",MUTED,11f).apply{gravity=Gravity.CENTER})
  setContentView(root);search.addTextChangedListener(object: android.text.TextWatcher { override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){refresh()};override fun afterTextChanged(s:android.text.Editable?){} });refresh()
 }
 private fun refresh() { if(!::list.isInitialized)return;list.removeAllViews();val items=db.all(search.text.toString());count.text="${items.size} contact${if(items.size==1)"" else "s"} enregistré${if(items.size==1)"" else "s"}";if(items.isEmpty()){list.addView(label("Aucun contact trouvé\nAjoutez un contact pour commencer.",MUTED,16f).apply{gravity=Gravity.CENTER;setPadding(0,dp(45),0,dp(45))});return};items.forEach { c -> val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(13),dp(12),dp(12));background=rounded(PANEL,dp(16))};val row=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL};row.addView(label(c.name,WHITE,17f).apply{typeface=Typeface.DEFAULT_BOLD},LinearLayout.LayoutParams(0,-2,1f));row.addView(action("Appeler",GREEN,BG){ startActivity(Intent(this,SipActivity::class.java).putExtra("number",c.number)) });row.addView(action("✎",PANEL,GREEN){edit(c)});row.addView(action("✕",PANEL,0xFFFF7777.toInt()){confirmDelete(c)});card.addView(row);card.addView(label("${c.number}${if(c.service.isBlank())"" else "  •  ${c.service}"}",MUTED,14f));val lp=LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(10);list.addView(card,lp) } }
 private fun edit(c:ContactItem?) { val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(8),dp(20),0)};val name=field("Nom complet",c?.name.orEmpty());val num=field("Numéro / extension",c?.number.orEmpty());val service=field("Service (facultatif)",c?.service.orEmpty());box.addView(name);box.addView(num);box.addView(service);AlertDialog.Builder(this).setTitle(if(c==null)"Nouveau contact" else "Modifier le contact").setView(box).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer"){_,_->val n=name.text.toString().trim();val p=num.text.toString().trim();if(n.isBlank()||p.isBlank()){toast("Le nom et le numéro sont obligatoires")}else{db.save(ContactItem(c?.id?:0,n,p,service.text.toString().trim()));refresh()}}.show() }
 private fun confirmDelete(c:ContactItem){AlertDialog.Builder(this).setTitle("Supprimer le contact ?").setMessage("${c.name} sera supprimé du répertoire.").setNegativeButton("Annuler",null).setPositiveButton("Supprimer"){_,_->db.delete(c.id);refresh();toast("Contact supprimé")}.show()}
 private fun field(h:String,v:String)=EditText(this).apply{hint=h;setText(v);setTextColor(WHITE);setHintTextColor(MUTED);setSingleLine(true)}
 private fun label(t:String,col:Int,size:Float)=TextView(this).apply{text=t;setTextColor(col);textSize=size}
 private fun action(t:String,bg:Int,fg:Int,on:()->Unit)=TextView(this).apply{text=t;setTextColor(fg);textSize=14f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setPadding(dp(12),dp(10),dp(12),dp(10));background=rounded(bg,dp(12));setOnClickListener{on()}}
 private fun rounded(color:Int,r:Int)=GradientDrawable().apply{setColor(color);cornerRadius=r.toFloat()}
 private fun space(h:Int)=View(this).apply{layoutParams=LinearLayout.LayoutParams(1,dp(h))}
 private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
