package ma.atfil.telephone

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class SipActivity : Activity() {
 private lateinit var user: EditText; private lateinit var host: EditText; private lateinit var pass: EditText; private lateinit var port: EditText; private lateinit var target: EditText; private lateinit var state: TextView
 private val prefs by lazy { getSharedPreferences("sip", MODE_PRIVATE) }
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(22),dp(20),dp(24));setBackgroundColor(0xFF07111F.toInt())};val sc=ScrollView(this);sc.addView(root);setContentView(sc)
  root.addView(text("AT-FIL  /  TÉLÉPHONIE",0xFF19F59A.toInt(),14f));root.addView(text("Compte SIP",Color.WHITE,30f,true));root.addView(text("Configurez votre extension pour passer et recevoir des appels.",0xFF9DB3B0.toInt(),15f));root.addView(space(18))
  user=field("Utilisateur / extension",prefs.getString("user", "").orEmpty());host=field("Serveur SIP / domaine",prefs.getString("host", "").orEmpty());pass=field("Mot de passe SIP",prefs.getString("pass", "").orEmpty(),true);port=field("Port SIP",prefs.getString("port","5060").orEmpty());listOf("Utilisateur / extension" to user,"Serveur SIP / domaine" to host,"Mot de passe SIP" to pass,"Port SIP" to port).forEach{root.addView(text(it.first,Color.WHITE,14f,true));root.addView(it.second);root.addView(space(10))}
  root.addView(text("Transport",Color.WHITE,14f,true));val transport=Spinner(this);transport.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("UDP","TCP","TLS"));root.addView(transport);root.addView(space(16))
  root.addView(button("Enregistrer et connecter",0xFF25D9EF.toInt(),0xFF07111F.toInt()){ if(user.text.isBlank()||host.text.isBlank()||pass.text.isBlank()){toast("Complétez les champs du compte SIP")}else{prefs.edit().putString("user",user.text.toString()).putString("host",host.text.toString()).putString("pass",pass.text.toString()).putString("port",port.text.toString()).putString("transport",transport.selectedItem.toString()).apply();if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.RECORD_AUDIO),4)};try{SipEngine.connect(applicationContext,user.text.toString().trim(),host.text.toString().trim(),pass.text.toString(),port.text.toString().toIntOrNull()?:5060,transport.selectedItem.toString());state.text="Initialisation SIP…"}catch(e:Exception){state.text="Erreur SIP : ${e.message}"}}})
  state=text("État : non connecté",0xFF9DB3B0.toInt(),14f);state.setPadding(dp(14),dp(18),dp(14),dp(18));state.background=rounded(0xFF102A24.toInt());root.addView(space(12));root.addView(state);root.addView(space(20));root.addView(text("Clavier d’appel",Color.WHITE,24f,true));target=field("Numéro ou extension à appeler",intent.getStringExtra("number").orEmpty());root.addView(target);root.addView(space(12));root.addView(button("☎  Appeler",0xFF19F59A.toInt(),0xFF07111F.toInt()){try{SipEngine.call(target.text.toString());state.text="Appel en cours…"}catch(e:Exception){state.text="Impossible d’appeler : ${e.message}"}});root.addView(space(8));root.addView(button("Raccrocher",0xFF44252D.toInt(),Color.WHITE){try{SipEngine.activeCall?.terminate();state.text="Appel terminé"}catch(e:Exception){state.text="Erreur : ${e.message}"}});root.addView(space(8));root.addView(button("← Retour à l’annuaire",0xFF102A24.toInt(),Color.WHITE){finish()})
 }
 private fun field(h:String,v:String="",secret:Boolean=false)=EditText(this).apply{hint=h;setText(v);setTextColor(Color.WHITE);setHintTextColor(0xFF9DB3B0.toInt());textSize=16f;singleLine=true;setPadding(dp(15),dp(12),dp(15),dp(12));background=rounded(0xFF1C2B3E.toInt());if(secret)inputType=129}
 private fun text(t:String,c:Int,s:Float,b:Boolean=false)=TextView(this).apply{text=t;setTextColor(c);textSize=s;if(b)typeface=Typeface.DEFAULT_BOLD}
 private fun button(t:String,bg:Int,fg:Int,fn:()->Unit)=TextView(this).apply{text=t;setTextColor(fg);textSize=16f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setPadding(dp(14),dp(16),dp(14),dp(16));background=rounded(bg);setOnClickListener{fn()}}
 private fun rounded(c:Int)=GradientDrawable().apply{setColor(c);cornerRadius=dp(15).toFloat()}
 private fun space(h:Int)=android.view.View(this).apply{layoutParams=LinearLayout.LayoutParams(1,dp(h))};private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt();private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
