plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "ma.atfil.telephone"
    compileSdk = 35
    defaultConfig { applicationId = "ma.atfil.telephone"; minSdk = 24; targetSdk = 35; versionCode = 1; versionName = "1.0.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("org.linphone:linphone-sdk-android:5.4.128")
}
