# AT-FIL Téléphone — nouveau projet

Projet Android natif Kotlin créé dans une nouvelle structure, avec une identité visuelle sombre/vert néon, un annuaire SQLite (ajout, recherche, modification, suppression confirmée) et un écran SIP utilisant Liblinphone.

## Générer l'APK
1. Importer ce dossier/ZIP dans un dépôt GitHub.
2. L'action GitHub `Android build` compile l'application et publie l'APK comme artefact.
3. Installer l'APK sur un appareil Android pour tester l'annuaire et configurer un vrai compte SIP.

Le fonctionnement SIP réel dépend du serveur, des identifiants, du réseau et des règles du PBX. Ce projet source n'a pas été compilé sur un appareil dans cet environnement.
