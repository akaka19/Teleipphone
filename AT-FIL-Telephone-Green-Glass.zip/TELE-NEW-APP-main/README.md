# AT-FIL Téléphone — Green Glass Edition

Android application project for a professional SIP telephone directory, with a dark emerald/neon-green visual theme.

## Features included in the source
- Contact directory with local SQLite storage and add/edit/delete flows
- Company and external personnel directories
- SIP configuration and calling UI powered by the Linphone Android SDK dependency
- Import/export tools
- App lock/security and biometric integration where supported
- About page and update workflow

## Build
Open the project in Android Studio, or push it to GitHub and run **Actions → Build AT-FIL Telephone**. The workflow uploads a debug APK artifact if the build succeeds.

## Important testing note
A successful APK build does not by itself verify SIP registration, inbound calls in the background, Bluetooth routing, or every device-specific permission. Test those against your company's SIP server and target Android devices before production use. Never commit SIP passwords to source control.
